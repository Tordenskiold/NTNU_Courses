import numpy as np
import skimage
import utils
import pathlib


def otsu_thresholding(im: np.ndarray) -> int:
    """
        Otsu's thresholding algorithm that segments an image into 1 or 0 (True or False)
        The function takes in a grayscale image and outputs a boolean image

        args:
            im: np.ndarray of shape (H, W) in the range [0, 255] (dtype=np.uint8)
        return:
            (int) the computed thresholding value
    """
    assert im.dtype == np.uint8
    ### START YOUR CODE HERE ### (You can change anything inside this block)

    """   Step 1   """
    pixel_count = im.shape[0] * im.shape[1]
    histogram = np.zeros((256, ))
    for y in range(im.shape[0]):
        for x in range(im.shape[1]):
            histogram[im[y,x]] += 1
    normalized_histogram = np.divide(histogram, pixel_count)

    """   Step 2   """
    cumulative_sums = np.zeros((256, ))
    cumulative_sums[0] = normalized_histogram[0]
    for i in range(1, 256):
        cumulative_sums[i] = cumulative_sums[i-1] + normalized_histogram[i]

    """   Step 3   """
    cumulative_means = np.zeros((256, ))
    cumulative_means[0] = 0
    for i in range(1, 256):
        cumulative_means[i] = cumulative_means[i-1] + (i * normalized_histogram[i])

    """   Step 4   """
    global_mean = cumulative_means[-1]

    """   Step 5   """
    between_class_variance = np.zeros((256, ))
    for i in range(256):
        between_class_variance[i] = 0 if cumulative_sums[i] == 0 or cumulative_sums[i] == 1 else (((global_mean * cumulative_sums[i]) - cumulative_means[i])**2) / (cumulative_sums[i] * (1 - cumulative_sums[i]))

    """   Step 6   """
    max_value = -1
    for element in between_class_variance:
        max_value = max_value if max_value >= element else element
    indices = []
    for i in range(256):
        if between_class_variance[i] == max_value:
            indices.append(i)
    otsu_threshold = sum(indices) / len(indices)

    return otsu_threshold
    ### END YOUR CODE HERE ### 


if __name__ == "__main__":
    # DO NOT CHANGE
    impaths_to_segment = [
        pathlib.Path("thumbprint.png"),
        pathlib.Path("polymercell.png")
    ]
    for impath in impaths_to_segment:
        im = utils.read_image(impath)
        threshold = otsu_thresholding(im)
        print("Found optimal threshold:", threshold)

        # Segment the image by threshold
        segmented_image = (im >= threshold)
        assert im.shape == segmented_image.shape, \
            "Expected image shape ({}) to be same as thresholded image shape ({})".format(
                im.shape, segmented_image.shape)
        assert segmented_image.dtype == np.bool, \
            "Expected thresholded image dtype to be np.bool. Was: {}".format(
                segmented_image.dtype)

        segmented_image = utils.to_uint8(segmented_image)

        save_path = "{}-segmented.png".format(impath.stem)
        utils.save_im(save_path, segmented_image)


