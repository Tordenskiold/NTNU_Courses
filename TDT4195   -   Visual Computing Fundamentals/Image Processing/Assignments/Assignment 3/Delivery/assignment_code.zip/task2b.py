import utils
import numpy as np
import matplotlib.pyplot as plt


def seed_neighbours(im: np.ndarray, seed_point: tuple, T: int):
    seed_value = im[seed_point]
    points = [seed_point]


def region_growing(im: np.ndarray, seed_points: list, T: int) -> np.ndarray:
    """
        A region growing algorithm that segments an image into 1 or 0 (True or False).
        Finds candidate pixels with a Moore-neighborhood (8-connectedness). 
        Uses pixel intensity thresholding with the threshold T as the homogeneity criteria.
        The function takes in a grayscale image and outputs a boolean image

        args:
            im: np.ndarray of shape (H, W) in the range [0, 255] (dtype=np.uint8)
            seed_points: list of list containing seed points (row, col). Ex:
                [[row1, col1], [row2, col2], ...]
            T: integer value defining the threshold to used for the homogeneity criteria.
        return:
            (np.ndarray) of shape (H, W). dtype=np.bool
    """
    ### START YOUR CODE HERE ### (You can change anything inside this block)
    # You can also define other helper functions
    if len(seed_points) < 1:
        return im

    segmented = region_growing_single_seed(im, seed_points[0], T)
    for i in range(1, len(seed_points)):
        segmented = np.logical_or(segmented, region_growing_single_seed(im, seed_points[i], T))

    _, ax = plt.subplots(1, 2, figsize=(10,5))
    ax[0].imshow(im, cmap="gray")
    ax[0].set_axis_off()
    ax[1].imshow(segmented, cmap="gray")
    ax[1].set_axis_off()
    plt.show()

    return segmented
    ### END YOUR CODE HERE ###


def region_growing_single_seed(im: np.ndarray, seed_point: list, T: int):
    seed_value = im[seed_point[0], seed_point[1]]
    y_max, x_max = im.shape
    points = [seed_point]
    checked = 0
    while len(points) > checked:
        for i in range(checked, len(points)):
            checked += 1
            candidate_points = neighbours(points[i], y_max, x_max)
            for candidate_point in candidate_points:
                candidate_value = int(im[candidate_point[0], candidate_point[1]])
                if diff(seed_value, candidate_value) <= T and candidate_point not in points:
                    points.append(candidate_point)
    segmented = np.zeros_like(im).astype(bool)
    for y, x in points:
        segmented[y, x] = True
    return segmented


def neighbours(point: list, y1: int, x1: int):
    points = []
    for y in range(point[0] - 1, point[0] + 2):
        for x in range(point[1] - 1, point[1] + 2):
            if [y, x] != point and 0 <= y < y1 and 0 <= x < x1:
                points.append([y, x])
    return points


def diff(u: int, v: int):
    return abs(u - v)


if __name__ == "__main__":
    # DO NOT CHANGE
    im = utils.read_image("defective-weld.png")

    seed_points = [ # (row, column)
        [254, 138], # Seed point 1
        [253, 296], # Seed point 2
        [233, 436], # Seed point 3
        [232, 417], # Seed point 4
    ]

    #im = np.array([[255,205,0,0,0],[100,0,0,0,0],[0,0,0,0,0],[0,0,155,205,0],[0,0,0,100,255]])
    #seed_points = [[0,0], [4,4]]

    intensity_threshold = 50
    segmented_image = region_growing(im, seed_points, intensity_threshold)

    assert im.shape == segmented_image.shape, \
        "Expected image shape ({}) to be same as thresholded image shape ({})".format(
            im.shape, segmented_image.shape)
    assert segmented_image.dtype == np.bool, \
        "Expected thresholded image dtype to be np.bool. Was: {}".format(
            segmented_image.dtype)

    segmented_image = utils.to_uint8(segmented_image)
    utils.save_im("defective-weld-segmented.png", segmented_image)

