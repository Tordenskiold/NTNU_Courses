import matplotlib.pyplot as plt
import numpy as np
import skimage
import utils
from scipy import fftpack




def convolve_im(im: np.array,
                fft_kernel: np.array,
                verbose=True):
    """ Convolves the image (im) with the frequency kernel (fft_kernel),
        and returns the resulting image.

        "verbose" can be used for visualizing different parts of the 
        convolution

    Args:
        im: np.array of shape [H, W]
        fft_kernel: np.array of shape [H, W] 
        verbose: bool
    Returns:
        im: np.array of shape [H, W]
    """
    ### START YOUR CODE HERE ### (You can change anything inside this block)

    fft_im = np.fft.fft2(im)

    fft_imK = fft_im * fft_kernel

    conv_result = np.real(np.fft.ifft2(fft_imK))

    amp1 = np.log(1 + np.abs(np.fft.fftshift(fft_im)))
    amp2 = np.log(1 + np.abs(np.fft.fftshift(fft_imK)))

    if verbose:
        _0, ax0 = plt.subplots(1, 2, figsize=(10, 5))
        ax0[0].imshow(im, cmap="gray")
        ax0[0].set_axis_off()
        ax0[1].imshow(conv_result, cmap="gray")
        ax0[1].set_axis_off()
        plt.show()

        _1, ax1 = plt.subplots(1, 2, figsize=(10, 5))
        ax1[0].imshow(amp1, cmap=plt.cm.gray)
        ax1[0].set_axis_off()
        ax1[1].imshow(amp2, cmap=plt.cm.gray)
        ax1[1].set_axis_off()
        plt.show()
    ### END YOUR CODE HERE ###
    return conv_result


if __name__ == "__main__":
    verbose = True

    # Changing this code should not be needed
    im = skimage.data.camera()
    im = utils.uint8_to_float(im)
    # DO NOT CHANGE
    frequency_kernel_low_pass = utils.create_low_pass_frequency_kernel(im, radius=50)
    image_low_pass = convolve_im(im, frequency_kernel_low_pass,
                                 verbose=verbose)
    # DO NOT CHANGE
    frequency_kernel_high_pass = utils.create_high_pass_frequency_kernel(im, radius=50)
    image_high_pass = convolve_im(im, frequency_kernel_high_pass,
                                  verbose=verbose)

    #if verbose:
        #plt.show()
    utils.save_im("camera_low_pass.png", image_low_pass)
    utils.save_im("camera_high_pass.png", image_high_pass)

    print("\n\nHigh\n\n", frequency_kernel_low_pass)
    print("\n\nLow\n\n", frequency_kernel_high_pass)

