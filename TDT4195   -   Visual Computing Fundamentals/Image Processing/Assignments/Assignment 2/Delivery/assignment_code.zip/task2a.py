import math

import skimage
import numpy as np
import utils


def MaxPool2d(im: np.array,
              kernel_size: int):
    """ A function that max pools an image with size kernel size.
    Assume that the stride is equal to the kernel size, and that the kernel size is even.

    Args:
        im: [np.array of shape [H, W, 3]]
        kernel_size: integer
    Returns:
        im: [np.array of shape [H/kernel_size, W/kernel_size, 3]].
    """
    stride = kernel_size
    ### START YOUR CODE HERE ### (You can change anything inside this block) 
    out = np.zeros((math.ceil(len(im)/kernel_size), math.ceil(len(im[0])/kernel_size), 3))
    for y in range(len(out)):
        for x in range(len(out[y])):
            max_r = 0
            max_g = 0
            max_b = 0
            for j in range(y * stride, (y + 1) * stride):
                if j >= len(im):
                    break
                for i in range(x * stride, (x + 1) * stride):
                    if (i >= len(im[j])):
                        break
                    max_r = max_r if max_r >= im[j, i, 0] else im[j, i, 0]
                    max_g = max_g if max_g >= im[j, i, 1] else im[j, i, 1]
                    max_b = max_b if max_b >= im[j, i, 2] else im[j, i, 2]
            out[y, x] = np.array([max_r, max_g, max_b])
    return out
    ### END YOUR CODE HERE ### 


if __name__ == "__main__":

    # DO NOT CHANGE
    im = skimage.data.chelsea()
    im = utils.uint8_to_float(im)
    max_pooled_image = MaxPool2d(im, 4)

    utils.save_im("chelsea.png", im)
    utils.save_im("chelsea_maxpooled.png", max_pooled_image)

    im = utils.create_checkerboard()
    im = utils.uint8_to_float(im)
    utils.save_im("checkerboard.png", im)
    max_pooled_image = MaxPool2d(im, 2)
    utils.save_im("checkerboard_maxpooled.png", max_pooled_image)